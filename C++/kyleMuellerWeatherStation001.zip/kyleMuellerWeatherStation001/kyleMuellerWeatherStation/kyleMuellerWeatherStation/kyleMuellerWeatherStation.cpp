// kyleMuellerWeatherStation.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
using namespace std;

int main()
{
	string name, direction;
	int temp, wind;
	name = "Brick Township";
	temp = 100;
	wind = 5;
	direction = "N";
	cout << "Current weather data for: " << name << endl;
	cout << "Temperature: " << temp << " F" << endl;
	cout << "Windspeed and direction: " << wind << " " << direction << endl;
	
	return 0;

}

