// kyleMuellerWeatherStation.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <sstream>
using namespace std;

int main()
{
	string name;
	string direction;
	string mystr;
	int temp;
	int wind;

	cout << "Give the name of the Weather Station:";
	getline(cin, name);

	cout << "Give the temperature at location (as an integer in F):";
	getline(cin, mystr);
	stringstream(mystr) >> temp;

	cout << "Give the wind speed at location (as an integer in mph):";
	getline(cin, mystr);
	stringstream(mystr) >> wind;

	cout << "Give the wind direction at location (preferably cardinal directions)";
	getline(cin, direction);

	cout << "Current weather data for: " << name << endl;
	cout << "Temperature: " << temp << " F" << endl;
	cout << "Windspeed and direction: " << wind << " " << direction << endl;


	return 0;
}

