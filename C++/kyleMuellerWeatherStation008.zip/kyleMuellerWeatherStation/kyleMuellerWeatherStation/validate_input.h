#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <regex>
#include "weatherMeasurement.h"

using namespace std;


bool valid_input(string inputStr, string validStr);
bool checkTomSawyer(string yeah);
int getControlNum(int arraySize);
void printHistory(string nombre, int hC, int hI, weatherMeasurement_t w[], int aS);