// kyleMuellerWeatherStation.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <sstream>
#include <regex>
#include "validate_input.h"
#include "weatherMeasurement.h"
using namespace std;

int main()
{
	string name;
	string mystr;
	bool flag = false;

	string sizeRegex = "[1-9]|[0-9]{2,6}";
	
	cout << "Hello welcome to the weather station viewer!" << endl;
	cout << "Voted the best weather viewing service by nobody, but my cat" << endl;
	
	do {
		cout << "Give the name of the Weather Station: (cannot be an empty imput)" << endl;
		getline(cin, mystr);
		if ((mystr.length() == 0) || checkTomSawyer(mystr)) {
			cout << "Bro read the instructions. No empty inputs." << endl;
		}
	} while ((mystr.length() == 0) || checkTomSawyer(mystr));
	stringstream(mystr) >> name;

	do {
		cout << "Please enter a positive integer for the size of the history array(Max 999,999): ";
		getline(cin, mystr);
	} while (!valid_input(mystr, sizeRegex) || checkTomSawyer(mystr));

	int arraySize;
	stringstream(mystr) >> arraySize;
	 
	weatherMeasurement_t * weatherHist;
	weatherHist = new weatherMeasurement_t[arraySize];

	int historyCount = 0;
	int historyIndex = 0;

	int num = 1;
	
	weatherMeasurement_t temporary;
	
	while (num != 0) {
		num = getControlNum(arraySize);
		if (num == 1) {
			temporary.setWeatherMeasurementData();
			weatherHist[historyIndex] = temporary;
			flag = true;
			historyCount++;
			historyIndex++;
			historyIndex = historyIndex % arraySize;  
		}	
		if (num == 1 || num == 2) {
			if (flag == true) {
				temporary.printSingleMeasurement(name, temporary.myTemp.temperature, temporary.myWind.speed, temporary.myWind.direction);
			}
			else {
				cout << "No input to print." << endl;
			}
		}
		else if (num == 3) {
			if (flag == true) {
				printHistory(name, historyCount, historyIndex, weatherHist, arraySize);
			}
			else {
				cout << "Silly boy, you did not enter any inputs. I can't show you any." << endl;
			}
		}
	}
	return 0;
}

