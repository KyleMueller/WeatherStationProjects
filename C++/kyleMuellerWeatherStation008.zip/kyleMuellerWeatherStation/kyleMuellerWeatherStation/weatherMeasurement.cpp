#include "stdafx.h"
#include "weatherMeasurement.h"
#include <iostream>
#include <regex>
#include <string>
#include <sstream>
#include "validate_input.h"
#include "temperature.h"
#include "wind.h"

using namespace std;

weatherMeasurement_t weatherMeasurement_t::setWeatherMeasurementData() {
	myTemp.setTemperature(); //delete result after changing this to a class
	myWind.setWindData(); //.setWindData
	return *this;
}


void weatherMeasurement_t::printSingleMeasurement(string name, int degrees, int windVelocity, string windBearing) {
	cout << endl << "Weather data for: " << name << endl;
	cout << "Temperature: " << degrees << endl;
	cout << "Windspeed and direction: " << windVelocity << " mph " << windBearing << endl;
	cout << endl; //put another space to clean up
}
