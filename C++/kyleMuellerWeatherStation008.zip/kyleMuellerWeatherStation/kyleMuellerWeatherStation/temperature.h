#pragma once
#include "stdafx.h"
#include <string>

using namespace std;
class temperature_t {
public:
	int temperature;
	temperature_t setTemperature();
};
