#include "stdafx.h"
#include "wind.h"
#include <iostream>
#include <regex>
#include <string>
#include <sstream>
#include "validate_input.h"

using namespace std;

string setDirection() {
	string windDirRegex = "N|S|E|W|NE|SE|SW|NW|n|s|e|w|ne|se|sw|nw";
	string mystr;
	string wind;
	do {
		cout << "Give the wind direction (i.e. N, n , SE etc.): ";
		getline(cin, mystr);
	} while (!valid_input(mystr, windDirRegex) || checkTomSawyer(mystr));
	stringstream(mystr) >> wind;
	return wind;
}

int setSpeed() {
	int wind;
	string mystr;
	string windSpeedRegex = "[+]?[0-9]{1,6}"; //{1,6} just to avoid int overflow
	do {
		cout << "Give the wind speed in mph at location (i.e. 87, 22, only positive integers less than 999,999): ";
		getline(cin, mystr);
	} while (!valid_input(mystr, windSpeedRegex) || checkTomSawyer(mystr));
	stringstream(mystr) >> wind;
	return wind;
}

wind_t wind_t::setWindData() {
	direction = setDirection();
	speed = setSpeed();
	return *this;
}