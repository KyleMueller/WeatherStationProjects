#include "stdafx.h"
#include "kyleMuellerWeatherStation.h"
#include <string>
#include <sstream>
#include <regex>
#include "validate_input.h"
#include "weatherMeasurement.h"
#include "language.h"
#include <list>
using namespace std;
map<int, weatherStation_t> myStations;
int getInputCommand() {
	string optionRegex = "[0-3]";
	string mystr;
	
	int num;
	do {
		cout << "Options:" << endl;
		cout << "0: exit all stations" << endl;
		cout << "1: new station" << endl;
		cout << "2: manage existent station" << endl;
		cout << "3: print all stations' histories" << endl;
		cout << "Response:";
		getline(cin, mystr);
	} while (!valid_input(mystr, optionRegex) || checkTomSawyer(mystr));
	stringstream(mystr) >> num;
	return num;
}


int main() {
	
	string mystr;
	bool flag = false;
	int num = 1;
	int numStations = 0;
	language_t::instance->loadLanguage();
	while (true) {
		num = getInputCommand();
		if (num == 0) {
			break;
		}
		else if (num == 1) { //new station

			myStations[numStations] = *(new weatherStation_t());
			numStations++;

			flag = true;
		}
		else if (num == 2) { //manage station
			if (flag) {
				cout << "Select a Station:" << endl;
				string inputRegex = "[1-9]|[0-9]{2,4}";
				int temp = -1;
				int choice;

				do{
					for (int i = 1; i <= numStations; i++) {
						cout << i << ":" << myStations[i].getName() << endl;
						cout << "Choice:";
						getline(cin, mystr);
						if (!valid_input(mystr, inputRegex)) {
							continue;
						}
						stringstream(mystr, temp);
					}

				}while (!valid_input(mystr, inputRegex) || temp > numStations);
				stringstream(mystr) >> choice;
				myStations[choice].orignalProcess();
				
				
			}
			else {
				cout << "No Stations exist." << endl;
			}
		}
		else { //print all histories, num == 3
			cout << "Finish later;" << endl;
		}
		
	}
	return 0;
}