#pragma once
#include <string>
#include "weatherMeasurement.h"
#include <map>

using namespace std;

class weatherStation_t {
public:
	weatherMeasurement_t*  weatherHist;
	void weatherStation_t::orignalProcess();
	void weatherStation_t::printStationHistory();
	weatherStation_t::weatherStation_t();
	string getName();
	int historyCount;
	int historyIndex;
private:
	int arraySize;
	string name;
};
