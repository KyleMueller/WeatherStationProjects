// kyleMuellerWeatherStation.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <sstream>
#include <regex>
#include "validate_input.h"
#include "weatherMeasurement.h"
#include "language.h"
#include "kyleMuellerWeatherStation.h"
using namespace std;
language_t *language_t::instance = 0;
map<string, string> language_t::langMap;



weatherStation_t::weatherStation_t() {
	cout << language_t::get("hello1") << endl; //hello1
	cout << language_t::get("hello2") << endl; //hello2
	string mystr;
	historyIndex = 0;
	historyCount = 0;
	do {
		cout << language_t::get("name") << endl;//name
		getline(cin, mystr);
		if ((mystr.length() == 0) || checkTomSawyer(mystr)) {
			cout << language_t::get("nameFail") << endl;//nameFail
		}
	} while ((mystr.length() == 0) || checkTomSawyer(mystr));
	stringstream(mystr) >> name;
	string sizeRegex = "[1-9]|[0-9]{2,6}";
	do{
		cout << language_t::get("histSize"); //histSize
		getline(cin, mystr);
	} while (!valid_input(mystr, sizeRegex) || checkTomSawyer(mystr));
	stringstream(mystr) >> arraySize;
	weatherHist = new weatherMeasurement_t[arraySize];

}
string weatherStation_t::getName()
{
	return name;
}
void weatherStation_t::printStationHistory() {
	bool flag = false;
	if (historyCount != 0) {
		flag = true;
	}
	if (flag == true) {
		printHistory(name, historyCount, historyIndex, weatherHist, arraySize);
	}
	else {
		cout << language_t::get("nada2") << endl; //nada2
	}

}

void weatherStation_t::orignalProcess()
{
	weatherMeasurement_t temporary;
	int num = 1;
	bool flag = false;
	while (true) {
		num = getControlNum(arraySize);
		if (num == 0) {
			break;
		}
		if (historyCount != 0) {
			flag = true;
		}
		if (num == 1) {
			temporary.setWeatherMeasurementData();
			
			weatherHist[historyIndex] = temporary;
			historyCount++;
			historyIndex++;
			
			historyIndex = historyIndex % arraySize;  
		}	
		if (num == 1 || num == 2) {
			if (flag == true) {
				temporary.printSingleMeasurement(name, temporary.myTemp.temperature, temporary.myWind.speed, temporary.myWind.direction);
			}
			else {
				cout << language_t::get("nada1") << endl; //nada1
			}
		}
		else if (num == 3) {
			if (flag == true) {
				printHistory(name, historyCount, historyIndex, weatherHist, arraySize);
			}
			else {
				cout << language_t::get("nada2") << endl; //nada2
			}
		}
	}
	
}

