#include "stdafx.h"
#include <iostream>
#include <string>
#include <sstream>
#include <regex>
#include "validate_input.h"
#include "weatherMeasurement.h"
#include "language.h"

using namespace std;

bool valid_input(string inputStr, string validStr) {
	const char*test = inputStr.c_str();
	regex re(validStr);
	cmatch match;
	if (regex_match(test, match, re)) {
		return true;
	}
	else {
		cout << language_t::get("valid1") << endl; //valid1
		cout << language_t::get("valid2") << endl; //valid2
		return false;
	}
}
bool checkTomSawyer(string yeah) {
	if (yeah.length() > 100) {
		cout << language_t::get("tom") << endl; //tom
		return true;
	}
	else {
		return false;
	}
}
int getControlNum(int arraySize) {
	string mystr;
	int num;
	string repeatRegex = "[0-3]";
	do {
		cout << endl << language_t::get("cont1") << endl; //cont1
		cout << language_t::get("cont2") << endl; //cont2
		cout << language_t::get("cont3") << endl; //cont3
		cout << language_t::get("cont4") << endl; //cont4
		cout << language_t::get("cont5") << arraySize << language_t::get("cont6") << endl; //cont5&6
		getline(cin, mystr);
	} while (!valid_input(mystr, repeatRegex) || checkTomSawyer(mystr));
	stringstream(mystr) >> num;
	return num;
}
void printHistory(string nombre, int hC, int hI, weatherMeasurement_t w[], int aS) {
	int readingCount = 1;
	cout << endl << language_t::get("pHist1") << aS << language_t::get("pHist2") << endl; //pHist1 & 2
	if (hC > aS) {
		int k = 1;
		int m;
		for (int r = 0; r < aS; r++) {
			hI--;
			if (hI == -1) {
				hI = aS - 1;
			}
			m = hI % aS;
			cout << language_t::get("readNum1") << k << language_t::get("readNum2") << endl; //readNum 1 & 2
			k++;
			w[m].printSingleMeasurement(nombre, w[m].myTemp.temperature, w[m].myWind.speed, w[m].myWind.direction);
		}
	}
	else {
		int j = 1;
		if (hI == 0) { hI = aS; }
		for (int i = hI - 1; i > -1; i--) {
			cout << language_t::get("readNum1") << j << language_t::get("readNum2") << endl; //readNum 1 & 2
			j++;
			w[i].printSingleMeasurement(nombre, w[i].myTemp.temperature, w[i].myWind.speed, w[i].myWind.direction);
		}
	}
}