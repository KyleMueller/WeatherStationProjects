weatherM1 Eatherway ataday orfay: 
weatherM2 Emperaturetay: 
weatherM3 Indspeedway andway irectionday: 
weatherM4  mphay 
getT Ivegay ethay emperaturetay atway ocationlay (i.e. -9F orway +27C orway 7): 
valid1 Ou'reyay inputway asway invalidway.
valid2 Ease play tryay againway
tom Omtay etgay outway ofway myay ogrampray!
cont1 Ouldway youway ikelay otay ubmitsay anotherway eadingray?
cont2 Inputway 0 otay exitway
cont3 Inputway 1 otay inputway away ataday eadingray andway intpray
cont4 Inputway 2 otay eprintray ethay ataday
cont5 Inputway 3 otay intpray ataday istoryhay (Upway otay astlay
cont6  Enteriesway)
pHist1  Isplayingday upway otay astlay
pHist2  Eadingsray: #1 asway ethay ostmay ecentray.
readNum1 Eadingray #
readNum2 :
hello1 Ellohay elcomeway otay ethay eatherway ationstay iewervay!
hello2 Otedvay ethay estbay eatherway iewingvay ervicesay byay obodynay, utbay myay atcay
name Ivegay ethay amenay ofway ethay eatherway ationstay: annot(cay ebay anway emptyway imput)way
nameFail Obray eadray ethay instructionsway. Onay emptyway inputsway.
histSize Easeplay enterway away ositivepay integerway orfay ethay izesay ofway ethay istoryhay array(maxway 999,999): 
nada1 Onay inputway otay intpray.
nada2 llysay oybay, youway idday otnay enterway anyway inputsway. Iway an'tcay owshay youway anyway.
windS Ivegay ethay indway irectionday i.E(ay. Nay nay , esay etc.): 
windD Ivegay ethay indway eedspay inway mphay atway ocationlay i.E(ay. 87, 22, onlyway ositivepay integersway esslay anthay 999,999):