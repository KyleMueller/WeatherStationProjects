#pragma once
#include "stdafx.h"
#include <string>

using namespace std;
class wind_t {
public:
	int speed;
	string direction;
	wind_t setWindData();
};



