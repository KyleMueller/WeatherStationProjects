#include "stdafx.h"
#include "temperature.h"
#include <iostream>
#include <regex>
#include <string>
#include <sstream>
#include "validate_input.h"
#include "language.h"

using namespace std;


int setTemp() {
	string tempRegex = "[-+]?[0-9]{1,6}";
	int temp;
	string mystr;
	do {
		cout << language_t::get("getT"); //getT
		getline(cin, mystr);
	} while (!valid_input(mystr, tempRegex) || checkTomSawyer(mystr));
	stringstream(mystr) >> temp;
	return temp;
}

temperature_t temperature_t::setTemperature() {
	temperature = setTemp();
	return *this;
}