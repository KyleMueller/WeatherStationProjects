#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <regex>
#include <string>
#include <sstream>
#include "validate_input.h"
#include "language.h"
#include <map>

using namespace std;

language_t::language_t() {

}
string language_t::get(string key) {
	if (instance == NULL) {
		instance = new language_t();
	}
	return langMap[key];
}
void language_t::loadLanguage() {
	string langName;
	string key;
	string value;
	string current;
	int pos;
	fstream* file = new fstream("knownLang.txt");
	map <string, string> knownLangauges;
	while (!file->eof()) {
		*file >> key;
		*file >> value;
		knownLangauges[key] = value;
	}
	cout << "Choose a language:\n";
	map<string, string>::iterator it;
	for (it = knownLangauges.begin(); it != knownLangauges.end(); ++it) {
		std::cout << it->first << std::endl;
	}
	string langRegex = "English|PigLatin";
	do {
		cout << "Choose:";
		getline(cin, langName);
	} while (!valid_input(langName, langRegex) || checkTomSawyer(langName));
	string myLang = "lang." + knownLangauges[langName];
	fstream* f =  new fstream(myLang);
	while (!f->eof()) {
		getline(*f, current);
		pos = (int)current.find(" ");
		value = current.substr(pos + 1);
		key = current.substr(0, pos);
		langMap[key] = value;
	}
}
