#pragma once
#include "stdafx.h"
#include <string>
#include "temperature.h"
#include "wind.h"

using namespace std;

class weatherMeasurement_t {
public:
	temperature_t myTemp;
	wind_t myWind;
	weatherMeasurement_t weatherMeasurement_t::setWeatherMeasurementData();
	void printSingleMeasurement(string name, int degrees, int windVelocity, string windBearing);
};


