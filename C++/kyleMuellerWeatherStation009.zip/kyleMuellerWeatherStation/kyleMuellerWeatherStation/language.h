#pragma once
#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <regex>
#include <string>
#include <sstream>
#include "validate_input.h"
#include <map>

using namespace std;
class language_t {
public:
	static string language_t::get(string key);
	void language_t::loadLanguage();
	static language_t* instance;

private:
	static map <string, string> langMap;
	language_t();
	

};