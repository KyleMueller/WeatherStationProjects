// kyleMuellerWeatherStation.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <sstream>
using namespace std;

int main()
{
	string name;
	string direction;
	string mystr;
	int temp;
	int wind;
	bool flag = false;
	while (true) {
		cout << "Give the name of the Weather Station:" << endl;
		getline(cin, mystr);
		if (mystr.length() == 0) {
			cout << "User entered no data, please try again." << endl;
		}
		else {
			break;
		}
	}
	name = mystr;


	int num = 42;

	while (num != 0) {
		while (true) {
			cout << endl << "What would you like to do?" << endl;
			cout << "(0 for exit, 1 to input data or 2 to print the data)" << endl;
			cout << "(any other input to reprint data)";
			getline(cin, mystr);
			if (mystr.length() == 0) {
				cout << "User entered no data, please try again." << endl;
			}
			else {
				break;
			}
		}
		stringstream(mystr) >> num;
		//double endline just to clean up the output
		cout << endl << endl;
		if (num == 1) {
			flag = true;
			while (true) {
				cout << "Give the temperature at location (as an integer in F):" << endl;
				getline(cin, mystr);
				if (mystr.length() == 0) {
					cout << "User entered no data, please try again." << endl;
				}
				else {
					break;
				}
			}
			stringstream(mystr) >> temp;
		}
		if (num == 1) {
			while (true) {
				cout << "Give the wind speed at location (as an integer in mph):" << endl;
				getline(cin, mystr);
				if (mystr.length() == 0) {
					cout << "User entered no data, please try again." << endl;
				}
				else {
					break;
				}
			}
			stringstream(mystr) >> wind;
		}
		if (num == 1) {
			while (true) {
				cout << "Give the wind direction at location (preferably cardinal directions)" << endl;
				getline(cin, direction);
				if (direction.length() == 0) {
					cout << "User entered no data, please try again." << endl;
				}
				else {
					break;
				}
			}
		}
		if (num == 2) {
			if (flag) {
				cout << endl << "Current weather data for: " << name << endl;
				cout << "Temperature: " << temp << " F" << endl;
				cout << "Windspeed and direction: " << wind << " " << direction << endl;
			}
			else {
				cout << "There is no data to print yet" << endl;
			}
		}
		
	}

	return 0;
}

