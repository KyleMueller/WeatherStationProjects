// kyleMuellerWeatherStation.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <sstream>
using namespace std;

int main()
{
	string name;
	string direction;
	string mystr;
	int temp;
	int wind;

	cout << "Give the name of the Weather Station:" << endl;
	getline(cin, name);




	int num = 2;
	while (num != 0) {
		if (num == 2 || num == 3) {
			while (true) {
				cout << "Give the temperature at location (as an integer in F):" << endl;
				getline(cin, mystr);
				if (mystr.length() == 0) {
					cout << "User entered no data, please try again." << endl;
				}
				else {
					break;
				}
			}
			stringstream(mystr) >> temp;
		}
		if (num == 2 || num == 4) {
			while (true) {
				cout << "Give the wind speed at location (as an integer in mph):" << endl;
				getline(cin, mystr);
				if (mystr.length() == 0) {
					cout << "User entered no data, please try again." << endl;
				}
				else {
					break;
				}
			}
			stringstream(mystr) >> wind;
		}
		if (num == 2 || num == 5) {
			while (true) {
				cout << "Give the wind direction at location (preferably cardinal directions)" << endl;
				getline(cin, direction);
				if (direction.length() == 0) {
					cout << "User entered no data, please try again." << endl;
				}
				else {
					break;
				}
			}
		}
		cout << endl << "Current weather data for: " << name << endl;
		cout << "Temperature: " << temp << " F" << endl;
		cout << "Windspeed and direction: " << wind << " " << direction << endl;
		while (true) {
			cout << endl << "Would you like to submit another reading?" << endl;
			cout <<  "(0 for exit, or 2 to reset the data)" << endl;
			cout << "(any other input to reprint data)";
			getline(cin, mystr);
			if (mystr.length() == 0) {
				cout << "User entered no data, please try again." << endl;
			}
			else {
				break;
			}
		}
		stringstream(mystr) >> num;
		//double endline just to clean up the output
		cout << endl << endl;
	}

	return 0;
}

