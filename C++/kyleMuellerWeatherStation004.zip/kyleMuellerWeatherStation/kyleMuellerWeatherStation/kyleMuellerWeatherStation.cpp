// kyleMuellerWeatherStation.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <sstream>
#include <regex>
using namespace std;

bool valid_input(string input, string validation) {
	const char*test = input.c_str();
	regex re(validation);
	cmatch match;
	if (regex_match(test, match, re)) {
		return true;
	}
	else {
		cout << "You're input was invalid." << endl;
		cout << "Please try Again" << endl;
		return false;
	}
}
bool checkTomSawyer(string yeah) {
	if (yeah.length() > 100) {
		cout << "Tom get out of my program!" << endl;
		return true;
	}
	else {
		return false;
	}
}
int setTemp() {
	string tempRegex = "[-+]?[0-9]+";
	int temp;
	string mystr;
	do {
		cout << "Give the temperature at location (i.e. -9F or +27C or 7): ";
		getline(cin, mystr);
	} while (!valid_input(mystr, tempRegex) || checkTomSawyer(mystr));
	stringstream(mystr) >> temp;
	return temp;
}
string setDirection() {
	string windDirRegex = "N|S|E|W|NE|SE|SW|NW|n|s|e|w|ne|se|sw|nw";
	string mystr;
	string wind;
	do {
		cout << "Give the wind direction (i.e. N, n , SE etc.): ";
		getline(cin, mystr);
	} while (!valid_input(mystr, windDirRegex) || checkTomSawyer(mystr));
	stringstream(mystr) >> wind;
	return wind;
}
int setSpeed() {
	int wind;
	string mystr;
	string windSpeedRegex = "[0-9]{1,6}"; //{1,6} just to avoid int overflow
	do {
		cout << "Give the wind speed in mph at location (i.e. 87, 22, only positive integers less than 999,999): ";
		getline(cin, mystr);
	} while (!valid_input(mystr, windSpeedRegex) || checkTomSawyer(mystr));
	stringstream(mystr) >> wind;
	return wind;
}


int main()
{
	string name;
	string direction;
	string mystr;
	int temp;
	int wind;
	bool flag = false;
	
	cout << "Hello welcome to the weather station viewer!" << endl;
	cout << "Voted the best weather viewing service by nobody, but my cat" << endl;

	do {
		cout << "Give the name of the Weather Station: (cannot be an empty imput)" << endl;
		getline(cin, mystr);
	} while ((mystr.length() == 0) || checkTomSawyer(mystr));
	stringstream(mystr) >> name;
	//regex Strings
	string tempRegex = "[-+]?[0-9]+";
	string windSpeedRegex = "[0-9]{1,6}"; //{1,6} just to avoid int overflow
	string windDirRegex = "N|S|E|W|NE|SE|SW|NW|n|s|e|w|ne|se|sw|nw";
	string repeatRegex = "[0-2]";

	int num = 1;
	
	while (num != 0) {
		do {
			cout << endl << "Would you like to submit another reading?" << endl;
			cout << "Input 0 to exit" << endl;
			cout << "Input 1 to set all data and print" << endl;
			cout << "Input 2 to print the data" << endl;
			getline(cin, mystr);
		} while (!valid_input(mystr, repeatRegex) || checkTomSawyer(mystr));
		stringstream(mystr) >> num;
		if (num == 1) {
			temp = setTemp();
			direction = setDirection();
			wind = setSpeed();
			flag = true;
		}	
		if (num == 1 || num == 2) {
			if (flag == true) {
				cout << endl << "Current weather data for: " << name << endl;
				cout << "Temperature: " << temp << endl;
				cout << "Windspeed and direction: " << wind << " " << direction << endl;
			}
			else {
				cout << "No input to print." << endl;
			}
		}
	}
	return 0;
}

