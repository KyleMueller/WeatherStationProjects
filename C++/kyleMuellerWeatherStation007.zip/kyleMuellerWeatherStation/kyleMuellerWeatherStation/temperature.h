#pragma once
#include "stdafx.h"
#include <string>

using namespace std;
struct temperature_t {
	int temperature;
};

temperature_t setTemperature();