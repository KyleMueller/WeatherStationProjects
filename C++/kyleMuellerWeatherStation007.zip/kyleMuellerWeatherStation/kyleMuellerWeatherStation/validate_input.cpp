#include "stdafx.h"
#include <iostream>
#include <string>
#include <sstream>
#include <regex>
#include "validate_input.h"

using namespace std;

bool valid_input(string inputStr, string validStr) {
	const char*test = inputStr.c_str();
	regex re(validStr);
	cmatch match;
	if (regex_match(test, match, re)) {
		return true;
	}
	else {
		cout << "You're input was invalid." << endl;
		cout << "Please try Again" << endl;
		return false;
	}
}
bool checkTomSawyer(string yeah) {
	if (yeah.length() > 100) {
		cout << "Tom get out of my program!" << endl;
		return true;
	}
	else {
		return false;
	}
}
int getControlNum(int arraySize) {
	string mystr;
	int num;
	string repeatRegex = "[0-3]";
	do {
		cout << endl << "Would you like to submit another reading?" << endl;
		cout << "Input 0 to exit" << endl;
		cout << "Input 1 to input a data reading and print" << endl;
		cout << "Input 2 to reprint the data" << endl;
		cout << "Input 3 to print data history (up to last " << arraySize << " enteries)" << endl;
		getline(cin, mystr);
	} while (!valid_input(mystr, repeatRegex) || checkTomSawyer(mystr));
	stringstream(mystr) >> num;
	return num;
}