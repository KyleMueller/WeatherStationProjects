#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <regex>

using namespace std;


bool valid_input(string inputStr, string validStr);
bool checkTomSawyer(string yeah);
int getControlNum(int arraySize);