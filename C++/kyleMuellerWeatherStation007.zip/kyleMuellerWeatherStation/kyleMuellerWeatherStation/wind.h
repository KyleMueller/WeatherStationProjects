#pragma once
#include "stdafx.h"
#include <string>

using namespace std;
struct wind_t {
	int speed;
	string direction;
};


wind_t setWindData();
