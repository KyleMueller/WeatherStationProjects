#include "stdafx.h"
#include "weatherMeasurement.h"
#include <iostream>
#include <regex>
#include <string>
#include <sstream>
#include "validate_input.h"
#include "temperature.h"
#include "wind.h"

using namespace std;

weatherMeasurement_t setWeatherMeasurementData() {
	weatherMeasurement_t result;
	result.myTemp = setTemperature();
	result.myWind = setWindData();
	return result;
}

void printHistory(string nombre, int hC, int hI, weatherMeasurement_t w[], int aS) {
	int readingCount = 1;
	cout << endl << "Displaying up to last " << aS << " readings: #1 as the most recent." << endl;
	if (hC > aS) {
		int k = 1;
		int m;
		for (int r = 0; r < aS; r++) {
			hI--;
			if (hI == -1) {
				hI = aS - 1;
			}
			m = hI % aS;
			cout << "Reading #" << k << ":" << endl;
			k++;
			printSingleMeasurement(nombre, w[m].myTemp.temperature, w[m].myWind.speed, w[m].myWind.direction);
		}
	}
	else {
		int j = 1;
		if (hI == 0) { hI = aS; }
		for (int i = hI - 1; i > -1; i--) {
			cout << "Reading #" << j;
			j++;
			printSingleMeasurement(nombre, w[i].myTemp.temperature, w[i].myWind.speed, w[i].myWind.direction);
		}
	}
}
void printSingleMeasurement(string name, int degrees, int windVelocity, string windBearing) {
	cout << endl << "Weather data for: " << name << endl;
	cout << "Temperature: " << degrees << endl;
	cout << "Windspeed and direction: " << windVelocity << " mph " << windBearing << endl;
	cout << endl; //put another space to clean up
}
