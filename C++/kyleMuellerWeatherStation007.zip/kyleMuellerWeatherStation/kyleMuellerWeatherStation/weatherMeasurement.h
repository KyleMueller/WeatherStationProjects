#pragma once
#include "stdafx.h"
#include <string>
#include "temperature.h"
#include "wind.h"

using namespace std;

struct weatherMeasurement_t {
	temperature_t myTemp;
	wind_t myWind;
};

weatherMeasurement_t setWeatherMeasurementData();
void printHistory(string nombre, int hC, int hI, weatherMeasurement_t w[], int aS);
void printSingleMeasurement(string name, int degrees, int windVelocity, string windBearing);
