// kyleMuellerWeatherStation.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <sstream>
#include <regex>
using namespace std;

bool valid_input(string input, string validation) {
	const char*test = input.c_str();
	regex re(validation);
	cmatch match;
	if (regex_match(test, match, re)) {
		return true;
	}
	else {
		cout << "You're input was invalid." << endl;
		cout << "Please try Again" << endl;
		return false;
	}
}
bool checkTomSawyer(string yeah) {
	if (yeah.length() > 100) {
		cout << "Tom get out of my program!" << endl;
		return true;
	}
	else {
		return false;
	}
}
int setTemp() {
	string tempRegex = "[-+]?[0-9]+";
	int temp;
	string mystr;
	do {
		cout << "Give the temperature at location (i.e. -9F or +27C or 7): ";
		getline(cin, mystr);
	} while (!valid_input(mystr, tempRegex) || checkTomSawyer(mystr));
	stringstream(mystr) >> temp;
	return temp;
}
string setDirection() {
	string windDirRegex = "N|S|E|W|NE|SE|SW|NW|n|s|e|w|ne|se|sw|nw";
	string mystr;
	string wind;
	do {
		cout << "Give the wind direction (i.e. N, n , SE etc.): ";
		getline(cin, mystr);
	} while (!valid_input(mystr, windDirRegex) || checkTomSawyer(mystr));
	stringstream(mystr) >> wind;
	return wind;
}
int setSpeed() {
	int wind;
	string mystr;
	string windSpeedRegex = "[+]?[0-9]{1,6}"; //{1,6} just to avoid int overflow
	do {
		cout << "Give the wind speed in mph at location (i.e. 87, 22, only positive integers less than 999,999): ";
		getline(cin, mystr);
	} while (!valid_input(mystr, windSpeedRegex) || checkTomSawyer(mystr));
	stringstream(mystr) >> wind;
	return wind;
}
void printHistory(int hC, int hI, int t[], int s[], string d[], int aS) {
	int readingCount = 1;
	cout << endl << "Displaying up to last four readings: #1 as the most recent." << endl;
	if (hC > aS) {
		int k = 1;
		int m;
		for (int r = 0; r < aS; r++) { 
			hI--;
			if (hI == -1) {
				hI = aS - 1;  
			}
			m = hI % aS; 
			
			cout << "Reading #" << k << ":" << endl;
			cout << "Temperature: " << t[m] << endl;
			cout << "Wind: " << s[m] << " mph " << d[m] << endl;
			cout << endl; //put another space to clean up
			k++;
			

		}

	}
	else {
		int j = 1;
		if (hI == 0) { hI = aS; }   
		for (int i = hI - 1; i > -1; i--) {
			cout << "Reading #" << j;
			j++;
			cout << ":" << endl; //not sure why, but wouldn't let me add this on the same line after j
			cout << "Temperature: " << t[i] << endl;
			cout << "Wind: " << s[i] << " mph " << d[i] << endl;
			cout << endl; //put another space to clean up
		}
	}
}



int main()
{
	string name;
	string direction;
	string mystr;
	int temp;
	int wind;
	bool flag = false;

	string sizeRegex = "[1-9]|[0-9]{2,6}";
	
	
	cout << "Hello welcome to the weather station viewer!" << endl;
	cout << "Voted the best weather viewing service by nobody, but my cat" << endl;

	do {
		cout << "Give the name of the Weather Station: (cannot be an empty imput)" << endl;
		getline(cin, mystr);
	} while ((mystr.length() == 0) || checkTomSawyer(mystr));
	stringstream(mystr) >> name;

	/**
		GET SIZE OF ARRAYS
	**/
	do {
		cout << "Please enter a positive integer for the size of the history array(Max 999,999): ";
		getline(cin, mystr);
	} while (!valid_input(mystr, sizeRegex) || checkTomSawyer(mystr));

	int arraySize;
	stringstream(mystr) >> arraySize;
	

	int * tempHistory;  
	int * windHistory;
	string * directionHistory;
	tempHistory = new int[arraySize];
	windHistory = new int[arraySize];
	directionHistory = new string[arraySize];  

	int historyCount = 0;
	int historyIndex = 0;

	int * histC;
	int * histI;

	//regex Strings
	string tempRegex = "[-+]?[0-9]+";
	string windSpeedRegex = "[+]?[0-9]{1,6}"; //{1,6} just to avoid int overflow
	string windDirRegex = "N|S|E|W|NE|SE|SW|NW|n|s|e|w|ne|se|sw|nw";
	string repeatRegex = "[0-3]";

	int num = 1;
	
	while (num != 0) {
		do {
			cout << endl << "Would you like to submit another reading?" << endl;
			cout << "Input 0 to exit" << endl;
			cout << "Input 1 to input a data reading and print" << endl;
			cout << "Input 2 to reprint the data" << endl;
			cout << "Input 3 to print data history (up to last " << arraySize << " enteries)" << endl;
			getline(cin, mystr);
		} while (!valid_input(mystr, repeatRegex) || checkTomSawyer(mystr));
		stringstream(mystr) >> num;
		if (num == 1) {
			temp = setTemp();
			tempHistory[historyIndex] = temp;
			direction = setDirection();
			directionHistory[historyIndex] = direction;
			wind = setSpeed();
			windHistory[historyIndex] = wind;
			flag = true;
			historyCount++;
			historyIndex++;
			historyIndex = historyIndex % arraySize;  
		}	
		if (num == 1 || num == 2) {
			if (flag == true) {
				cout << endl << "Current weather data for: " << name << endl;
				cout << "Temperature: " << temp << endl;
				cout << "Windspeed and direction: " << wind << " " << direction << endl;
			}
			else {
				cout << "No input to print." << endl;
			}
		}
		else if (num == 3) {
			if (flag == true) {
				printHistory(historyCount, historyIndex, tempHistory, windHistory, directionHistory, arraySize);
			}
			else {
				cout << "Silly boy, you did not enter any inputs. I can't show you any." << endl;
			}
		}
	}
	return 0;
}

